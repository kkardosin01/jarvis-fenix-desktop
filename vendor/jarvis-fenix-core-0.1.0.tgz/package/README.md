# jarvis-fenix-core

Núcleo de boletos compartilhado pelos dois apps Jarvis Fênix:

- **jarvis-fenix-desktop** (Electron, Windows)
- **jarvis-fenix** (PWA em Next.js na Vercel)

Os dois leem e-mails pessoais e gravam boletos na aba `Boletos_Outras_Contas` da planilha Jarvis_Fenix. Este pacote garante que achem e dedupliquem boletos **do mesmo jeito**.

| Módulo | O que faz |
| --- | --- |
| `jarvis-fenix-core/ptbr` | números, moeda e datas em pt-BR, fuso de São Paulo |
| `jarvis-fenix-core/boleto-codigo` | linha digitável (bancária e arrecadação), DVs, fator de vencimento, PIX copia-e-cola |
| `jarvis-fenix-core/extrair` | extração determinística de boletos do texto do e-mail e dos PDFs |
| `jarvis-fenix-core/boletos` | linhas da planilha → contas, situação, deduplicação entre as abas |
| `jarvis-fenix-core/types` | tipos compartilhados (Conta, DadosPainel, …) |
| `jarvis-fenix-core/whatsapp`, `jarvis-fenix-core/links` | links de WhatsApp e do Gmail |

Nada aqui faz rede nem lê arquivos: recebe texto, devolve dados.

## Desenvolvimento

```bash
npm install
npm test          # ptbr, linha digitável/PIX e extração com mensagens fictícias
npm run typecheck
npm run lint
npm run build     # gera dist/ (JS ESM + .d.ts)
```

## Como os apps recebem o pacote

O pacote **não** vai para registro npm nem é instalado direto do GitHub: os dois builds (Vercel e electron-builder) rodariam sem token para um repositório privado. Em vez disso, cada app guarda o tarball em `vendor/jarvis-fenix-core-<versão>.tgz` e o `package.json` aponta para ele (`file:vendor/...`).

Para publicar uma mudança nos dois apps (repositórios lado a lado na mesma pasta):

1. Altere o código aqui, com teste.
2. Suba a versão em `package.json` (`npm version patch --no-git-tag-version`).
3. `npm run entregar` — roda testes, empacota e instala o tarball novo em `../jarvis-fenix` (dependência) e `../jarvis-fenix-desktop` (devDependency, embutida no bundle pelo electron-vite).
4. Rode `npm test` e `npm run build` em cada app e faça o commit de `vendor/`, `package.json` e `package-lock.json` lá.

Não edite o código do núcleo dentro dos apps: ele vive só aqui.
